열염홍기 / 烈焰红旗 From 카트라이더 러쉬+(跑跑卡丁车官方竞速版)
+ Substitute Doll from Pokmeon LGPE

Kart Model Rip by amogusstrikesback2 (sketchfab.com/3d-models/red-flag-76bf74368d9841aa8240d67a60e6967f)
Substitute Doll Model Rip by Hallow (models.spriters-resource.com/nintendo_switch/pokemonletsgopikachueevee/asset/310161)

Small Edits & Import to TM2 by MokaCraft

─────────────

Check out more stuffs by me :D

- TMUF-X : tmuf.exchange/usershow/6697938
- TM2MX : tm.mania.exchange/usershow/151213
- MP : maniapark.com/usershow/151213
- Moka's Signs : sites.google.com/view/m0kasign