아르테미스 울트라 / Artemyzer Ultra From 카트라이더 러쉬+(Kartrider Rush+)
+ Substitute Doll from Pokmeon LGPE

Kart Model Rip by amogusstrikesback2 (sketchfab.com/3d-models/artemyzer-ultra-5e6c59f6ff5d4cc787a649f1b336545d)
Substitute Doll Model Rip by Hallow (models.spriters-resource.com/nintendo_switch/pokemonletsgopikachueevee/asset/310161)

Small Edits & Import to TM2 by MokaCraft

─────────────

Check out more stuffs by me :D

- TMUF-X : tmuf.exchange/usershow/6697938
- TM2MX : tm.mania.exchange/usershow/151213
- MP : maniapark.com/usershow/151213
- Moka's Signs : sites.google.com/view/m0kasign